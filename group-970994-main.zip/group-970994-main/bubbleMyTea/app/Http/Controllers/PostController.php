<?php

namespace App\Http\Controllers;


use App\Models\Inscription;
use Illuminate\Http\Request;
use App\Http\Controllers\ContactController;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        dd($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function home() 
    {
        return view('greeting');
    }

    public function login (){
        return view('login');
    }

    public function signup () {
        return view('signup');
    }

    public function userSend(Request $request)
    {
        $inscription = new Inscription();
        
        $validated = $request->validate([
            'nom' => 'required|alpha',
            'prenom' => 'required|alpha',
            'email' => 'required',
  
        ]);

        $inscription->nom = $request->nom;
        $inscription->prenom = $request->prenom;
        $inscription->email = $request->email;
        $inscription->mdp = $request->mdp;
        $inscription->confmdp = $request->confmdp;
        
        $inscription->save();
        
        return redirect()->route('login');
    }

    public function connexionSend()
    {
        request()->validate([
            'email' => ['required', 'email'],
            'mot de passe' => ['required'],
        ]);
        
        return redirect()->route('login');    
    }

    /*
    public function connexionSend(Request $request)
    {

        $connexion = new connexion();
        
        $validated = $request->validate([
            'email' => 'required',
            'mot de passe' => 'required'
        ]);

        $connexion->nom = $request->nom;
        $inscription->prenom = $request->prenom;
        $inscription->email = $request->email;
        $inscription->mdp = $request->mdp;
        $inscription->confmdp = $request->confmdp;
        
        $inscription->save();
        
        return redirect()->route('signup');
    
    }*/

}