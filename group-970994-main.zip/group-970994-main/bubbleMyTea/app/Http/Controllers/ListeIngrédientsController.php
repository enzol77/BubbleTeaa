<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ListeIngrédientsController extends Controller
{
    //
}
