<?php

use App\Http\Controllers\PostController;
use App\Http\Controllers\ConnexionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PostController::class, 'home'])->name('home');


Route::get('/signup', [PostController::class, 'signup'])->name('signup');
  
Route::post('/signup', [PostController::class, 'userSend']);

Route::get('/login', [PostController::class, 'login'])->name('login');

Route::post('/login', [PostController::class, 'connexionSend']);


Route::get('/accueil', function () {
    return view('accueil');     
});

Route::get('/modal', function () {
    return view('modal');     
});

Route::get('/profil', function () {
    return view('profil');
});
Route::get('/profil/orders', function () {
    return view('orders');
});
Route::get('/admin', function () {
    return view('admin');
});
Route::get('/admin/gestion', function () {
    return view('gestion');
});

/* Route::post('/login', [PostController::class, 'connexionSend']); */


/*Route::get('/login', [ConnexionController::class, 'formulaire']);

Route::post('/login', [ConnexionController::class, 'traitement']);*/

/*Route::get('/login', 'ConnexionController@formulaire');
Route::post('/login', 'ConnexionController@traitement');*/