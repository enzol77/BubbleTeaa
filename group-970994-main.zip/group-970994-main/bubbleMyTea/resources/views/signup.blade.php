@extends('Layouts.Default')

@section('main')

<section class="h-100 w-100 bg-white">
  <div class="container h-100 w-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class=" text-black w-100">
          <div class=" p-md-5 w-100">
            <div class="row justify-content-center w-100">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-2">Inscription</p>

                @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

                <form class="mx-1 mx-md-4" action="" method="POST">
                  @csrf

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingNom" placeholder="Nom" name="nom">
                    <label for="floatingNom">Nom</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingPrenom" placeholder="Prenom" name="prenom">
                    <label for="floatingPrenom">Prénom</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="floatingPassword" placeholder="Email" name="email">
                    <label for="floatingPassword">Email</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="mdp">
                    <label for="floatingPassword">Mot de passe</label>
                </div>
              
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="confmdp">
                    <label for="floatingPassword">Confirmer le mot de passe</label>
                </div>

                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <input type="submit" value="Enregistrer" class="w-100 btn btn-lg btn-primary">
                  </div>

                </form>
                
          
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection