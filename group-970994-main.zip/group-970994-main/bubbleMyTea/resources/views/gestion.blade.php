@extends('Layouts.Default')

@section('main')
<div class="page-content page-container w-100 h-100" id="page-content">
    <div class="padding mt-5 container d-flex justify-content-center w-100 h-100">
        <div class="row container d-flex justify-content-center">
            <div class="col-xl-12 col-md-12 w-100 h-100">
                <div class="card user-card-full h-100">
                    <div class="row m-l-0 m-r-0 h-100">
                        <div class="col-sm-4 bg-c-lite-green user-profile p-0">
                            <!-- button -->
                            <div class="btn-group-vertical btn-group-lg w-100" role="group" aria-label="Vertical button group">
                                <button type="button" class="btn btn-outline-dark">Profil</button>
                                <button type="button" class="btn btn-outline-dark">Gestion des produits</button>
                            </div>

                            <div class="btn-group-vertical btn-group-lg w-100 position-absolute bottom-0 start-0" role="group" aria-label="Vertical button group">
                                <button type="button" class="btn btn-outline-dark">Déconnecter</button>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            
                            <div class="card-block">
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
                            </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection