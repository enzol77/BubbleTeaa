@extends('Layouts.Default')

@section('main')
<div class="page-content page-container w-100 h-100" id="page-content">
    <div class="padding mt-5 container d-flex justify-content-center w-100 h-100">
        <div class="row container d-flex justify-content-center">
            <div class="col-xl-12 col-md-12 w-100 h-100">
                <div class="card user-card-full h-100">
                    <div class="row m-l-0 m-r-0 h-100">
                        <div class="col-sm-4 bg-c-lite-green user-profile p-0">
                            <!-- button -->
                            <div class="btn-group-vertical btn-group-lg w-100" role="group" aria-label="Vertical button group">
                                <button type="button" class="btn btn-outline-dark">Profil</button>
                                <button type="button" class="btn btn-outline-dark">Mes commandes</button>
                            </div>

                            <div class="btn-group-vertical btn-group-lg w-100 position-absolute bottom-0 start-0" role="group" aria-label="Vertical button group">
                                <button type="button" class="btn btn-outline-dark">Déconnecter</button>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
                                <div class="card-block text-center text-white">
                                <div class="m-b-25"> <img src="https://img.icons8.com/bubbles/100/000000/user.png" class="img-radius" alt="User-Profile-Image"> <button type="button" class="btn btn-secondary btn-sm">Edit</button></div>
                                <h6 class="f-w-600 text-dark">Prenom NOM</h6><button type="button" class="btn btn-secondary btn-sm">Edit</button>
                            </div>
                                <div class="row mb-3">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email</p>
                                        <h6 class="text-muted f-w-400">emailg@gmail.com</h6>
                                        <button type="button" class="btn btn-secondary btn-sm">Edit</button>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Téléphone</p>
                                        <h6 class="text-muted f-w-400">98979989898</h6>
                                        <button type="button" class="btn btn-secondary btn-sm">Edit</button>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Adresse</p>
                                        <h6 class="text-muted f-w-400">00 rue Grand Coyngh 90000 Ville</h6>
                                        <button type="button" class="btn btn-secondary btn-sm">Edit</button>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Derniere Connexion</p>
                                        <h6 class="text-muted f-w-400">--/--/-- --:--</h6>
                                    </div>
                                </div>

                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

