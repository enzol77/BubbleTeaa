@extends('Layouts.Default')

@section('main')    

<section class="h-100 w-100 bg-white mt-3">
  <div class="container h-100 w-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class=" text-black w-100">
          <div class=" p-md-5 w-100">
            <div class="row justify-content-center w-100">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                <form class="mx-1 mx-md-4" action="" method="POST" >
                @csrf

                <h1 class="h1 text-center mb-4 fw-bold mb-5 mx-1 mx-md-4 mt-2 d-flex justify-content-center">Connexion</h1>

                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="floatingPassword" placeholder="email">
                    <label for="floatingPassword">Email</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="mdp">
                    <label for="floatingPassword">Mot de passe</label>
                </div>


                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <input type="submit" value="Se connecter" class="w-100 btn btn-lg btn-primary">
                  </div>

                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
        
@endsection